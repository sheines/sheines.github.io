﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PolyDivTeX
{
    class Polynom
    {
        public Polynom() { }
        public Polynom(List<Fraction> c) // First (0) = highest expontent (n-1), decreasing order, Last (n-1) = lowest expontent (0) // Erster (0) = höchster Exponent (n-1), absteigende Sortierung, Letzter (n-1) = niedrigster Exponent (0)
        {
            Coefficients = c;
            for (int i = Coefficients.Count - 1; i >= 0; --i)
                Exponents.Add(i);
        }
        public Polynom(List<Fraction> c, List<int> n) // c[i] is the koefficient to x to the power of n[i] // c[i] ist der Koeffizient zu x hoch n[i]
        {
            Coefficients = c;
            Exponents = n;

            this.Sort();
        }
        public Polynom(Fraction f, int e)
        {
            Coefficients.Clear();
            Coefficients.Add(f);

            Exponents.Clear();
            Exponents.Add(e);
        }

        public static bool TeX { get; set; } = false;
        private static bool DiV { get; set; } = false;

        public List<int> Exponents { get; private set; } = new List<int>();
        public List<Fraction> Coefficients { get; private set; } = new List<Fraction>();

        public int Length { get { return Coefficients.Count; } }

        public static Polynom operator+ (Polynom A, Polynom B)
        {
            List<int> exp = new List<int>();
            List<Fraction> coeff = new List<Fraction>();

            for (int i = A.Degree > B.Degree ? A.Degree : B.Degree; i>=0; --i)
            {
                if (A.Exponents.Contains(i) && B.Exponents.Contains(i))
                {
                    
                    exp.Add(i);
                    coeff.Add(A.Coefficients[A.Exponents.FindIndex(x => x == i)] + B.Coefficients[B.Exponents.FindIndex(x => x == i)]);
                }
                else if (A.Exponents.Contains(i))
                {
                    exp.Add(i);
                    coeff.Add(A.Coefficients[A.Exponents.FindIndex(x => x == i)]);
                }
                else if (B.Exponents.Contains(i))
                {
                    exp.Add(i);
                    coeff.Add(B.Coefficients[B.Exponents.FindIndex(x => x == i)]);
                }
                else
                {
                    // Nothing to do.
                }
            }
            Polynom P = new Polynom(coeff, exp);
            P.Reduce();

            if (TeX && !DiV)
                StringSave.Add(A.ToTexString(-1,false) + " + " + B.ToTexString(-1,false) + " = " + P.ToTexString(-1,false)); 

            return P;
        }
        public static Polynom operator -(Polynom A, Polynom B)
        {
            List<int> exp = new List<int>();
            List<Fraction> coeff = new List<Fraction>();

            for (int i = A.Degree > B.Degree ? A.Degree : B.Degree; i >= 0; --i)
            {
                if (A.Exponents.Contains(i) && B.Exponents.Contains(i))
                {

                    exp.Add(i);
                    coeff.Add(A.Coefficients[A.Exponents.FindIndex(x => x == i)] - B.Coefficients[B.Exponents.FindIndex(x => x == i)]);
                }
                else if (A.Exponents.Contains(i))
                {
                    exp.Add(i);
                    coeff.Add(A.Coefficients[A.Exponents.FindIndex(x => x == i)]);
                }
                else if (B.Exponents.Contains(i))
                {
                    exp.Add(i);
                    coeff.Add(-1 * B.Coefficients[B.Exponents.FindIndex(x => x == i)]);
                }
                else
                {
                    // Nothing to do.
                }
            }
            Polynom P = new Polynom(coeff, exp);
            P.Reduce();

            if (TeX && !DiV)
                StringSave.Add(A.ToTexString(-1,false) + " - " + B.ToTexString(-1,true) + " = " + P.ToTexString(-1,false));

            return P;
        }
        public static Polynom operator*(Polynom A, Polynom B)
        {
            int degree = A.Degree + B.Degree;

            List<int> exp = new List<int>();
            List<Fraction> coeff = new List<Fraction>();

            for (int i=degree; i>=0; --i)
            {
                exp.Add(i);
                coeff.Add(0);
            }
            for (int i = 0; i<A.Coefficients.Count; ++i)
            {
                for (int j=0; j<B.Coefficients.Count; ++j)
                {
                    degree = A.Exponents[i] + B.Exponents[j];
                    degree = exp.IndexOf(degree);
                    coeff[degree] += A.Coefficients[i] * B.Coefficients[j];
                }
            }
            Polynom P = new Polynom(coeff, exp);
            P.Reduce();

            if (TeX && !DiV)
                StringSave.Add(A.ToTexString() + " \\cdot " + B.ToTexString() + " = " + P.ToTexString(-1,false));

            return P;
        }
        public static Polynom operator/(Polynom A, Polynom B)
        {
            DiV = true;
            if (A.Degree < B.Degree)
                return 0;

            Polynom C = new Polynom();

            List<int> exp = new List<int>();
            List<Fraction> coef = new List<Fraction>();

            int ex;
            Fraction a;

            if (TeX)
                StringSave.Add(A.ToTexString(-1,true,true,true) + "&:&" + B.ToTexString(-1,true, false,false) + " = \n");

            while (A.Degree >= B.Degree)
            {
                ex = A.Exponents[0] - B.Exponents[0];
                a = A.Coefficients[0] / B.Coefficients[0];

                exp.Add(ex);
                coef.Add(a);
                C = new Polynom(a, ex);
                C *= B;
                if (TeX)
                    StringSave.Add("-" + C.ToTexString(-1,true, true,true) + "cline \n");
                A -= C;
                if (TeX)
                    StringSave.Add(A.ToTexString(B.Length,false,true,true) + "\n");
            }
            Polynom P = new Polynom(coef, exp);
            if (TeX)
            {
                string[] s = StringSave.Text.Split('\n');
                s[2] += P.ToTexString(-1,false,false,false);
                if (A.Coefficients.Count!=0)
                {
                    s[2] += "+\\frac{" + A.ToTexString(-1,false,false,false) + "}{" + B.ToTexString(-1,false,false,false) + "}";
                }
                StringSave.Clear();
                StringSave.Add("\\arraycolsep=1.4pt\\newcommand{\\pb}{\\phantom{\\big)}}\n");
                StringSave.Add("\\begin{array}[t]{*{25}{r}}");
                int j = 1;
                string str;
                for (int i = 2; i < s.Length; ++i)
                {
                    str = "";
                    if (s[i].Trim() != String.Empty)
                    {

                        for (int k = 1; k < j; ++k)
                            str += "&";

                        str = str + ("\n" + s[i].Replace("cline", "") + "\\\\" + (s[i].Contains("cline") ? "\\cline{" + j.ToString() + "-" + (++j+B.Length-2).ToString() + "}" : ""));
                    }
                    StringSave.Add(str);
                }
                if (StringSave.Text.Trim().EndsWith("}"))
                {
                    for (int k = 1; k < j+B.Length-2; ++k)
                        StringSave.Add("&");
                    StringSave.Add("0\\pb");
                }
            }

            DiV = false;
            return P;
        }

        public static implicit operator Polynom(int i)
        {
            return new Polynom(i,0);
        }
        public static implicit operator Polynom(Fraction f)
        {
            return new Polynom(f, 0);
        }
        public int Degree // Gives degree of polynom // Gibt den Polynomgrad zurück
        {
            get { return Exponents.Count == 0 ? 0 : Exponents.Max(); }
        }

        void Expand() // Write every monom to the polynom, even these with coefficient = 0 // Jedes Monom ins Polynom schreiben, auch mit Koeffizient = 0
        {
            int n = Exponents.Max();

            List<int> exp = new List<int>();
            List<Fraction> coeff = new List<Fraction>();
            int index;

            for (int i = n; i >= 0; --i)
            {
                exp.Add(i);
                if (Exponents.Contains(i))
                {
                    index = Exponents.FindIndex(x => x == i);
                    coeff.Add(Coefficients[index]);
                }
                else
                {
                    coeff.Add(new Fraction());
                }
            }
            Exponents = exp;
            Coefficients = coeff;
        }

        public Polynom Expand(Polynom P) 
        {
            P.Expand();
            return P;
        }
        void Sort() // Sort coefficients in decreasing order of Exponents // Koeffizienten in absteigender Reihenfolge der Exponenten sortieren
        {
            List<int> exp = new List<int>();
            List<Fraction> coeff = new List<Fraction>();
            int index;

            while (Exponents.Count > 0)
            {
                index = Exponents.FindIndex(x => x == Exponents.Max());
                exp.Add(Exponents[index]);
                coeff.Add(Coefficients[index]);

                Exponents.RemoveAt(index);
                Coefficients.RemoveAt(index);
            }
            Exponents = exp;
            Coefficients = coeff;
        }
        public Polynom Sort(Polynom P) 
        {
            P.Sort();
            return P;

        }

        public void Reduce() // Remove all parts with coefficient = 0 // Alle Teile mit Koeffizient = 0 entfernen
        {
            for (int i = Exponents.Count-1; i>=0 ;--i)
            {
                if (Coefficients[i].Numerator == 0)
                {
                    Coefficients.RemoveAt(i);
                    Exponents.RemoveAt(i);
                }
            }
        } 
        Polynom Simplify()
        {
            return this * 1;
        }

        public override string ToString()
        {
            string str = "";
            for (int i = 0; i<Exponents.Count; ++i)
            {
                str += (Coefficients[i].Numerator >= 0 ? " +" + Coefficients[i].ToString() : " " + Coefficients[i].ToString()) + (Exponents[i] == 0 ? "" : (Exponents[i] == 1 ? "x" : " x^" + Exponents[i].ToString()));
            }
            return str;
        }
        public string ToTexString(int length = -1, bool brackets = true, bool phantom = false, bool sep = false)
        {
            string str = "";

            int max = length < Exponents.Count ? (length == -1 ? Exponents.Count : length) : Exponents.Count;

            for (int i = 0; i < max; ++i)
            {

                if (Coefficients[i].Numerator != 0)
                {
                    if (i != 0)
                        str += (Coefficients[i].Sign() ? (phantom? "+\\pb":"+") : (phantom ? "-\\pb" : "-")) + (Coefficients[i].IsOne() && Exponents[i] != 0 ? "" : Coefficients[i].ToTexString(false));
                    else
                    {
                        str += (brackets ? "\\big(" : "") + (Coefficients[i].Sign() ? "" : (phantom ? "-\\pb" : "-")) + (Coefficients[i].IsOne() && Exponents[i] != 0 ? "" : Coefficients[i].ToTexString(false));
                    }
                    if (Exponents[i] > 1)
                        str += " x^" + Exponents[i].ToString();
                    else if (Exponents[i] == 1)
                        str += " x";

                    if (i < Exponents.Count - 1)
                        str += (phantom ? "\\pb" : "") + (sep? "&" : "");
                    else
                        str += brackets ? "\\big)" : (phantom ? "\\pb" : "");
                }

            }
            return str;
        }


        public static Polynom GetPolynom (string s)
        {
            s = s.Replace(" ", string.Empty); ;

            List<int> signs = new List<int>(); // List with positions of + and - // Liste mit der Position von + und -

            List<int> exp = new List<int>();
            List<Fraction> coef = new List<Fraction>();


            for (int i = 0; i< s.Length; ++i)
            {
                if (s[i] == '+' || s[i] == '-')
                    signs.Add(i);

            }

            List<string> monoms = new List<string>();

            for (int i = 0; i <= signs.Count; ++i)
            {
                if (i == 0)
                    monoms.Add(s.Substring(0, signs[0]).Trim());
                else if (i< signs.Count)
                    monoms.Add(s.Substring(signs[i - 1], signs[i]-signs[i - 1]).Trim());
                else
                    monoms.Add(s.Substring(signs[i - 1], s.Length - signs[i - 1]).Trim());
            }

            for (int i = 0; i<monoms.Count; ++i)
            {
                if (monoms[i].Trim() != "")
                {
                    monoms[i].Replace('*', ' ').Trim();
                    string[] parts = monoms[i].Split('x');
                    
                    if (parts.Length > 1)
                    {
                        if (parts[1].Trim() == "")
                            exp.Add(1);
                        else 
                        {
                            int e;
                            int.TryParse(parts[1].Replace('^', ' '), out e);
                            exp.Add(e);
                        }
                        if (parts[0].Contains("/"))
                        {
                            int n, d;
                            string[] fraction = parts[0].Split('/');
                            int.TryParse(fraction[0], out n);
                            int.TryParse(fraction[1], out d);
                            coef.Add(new Fraction(n, d));
                        }
                        else
                        {
                            if (parts[0].Trim() == "")
                                coef.Add(1);
                            else if (parts[0].Trim() == "-")
                                coef.Add(-1);
                            else
                            {
                                int n;
                                int.TryParse(parts[0], out n);
                                coef.Add(n);
                            }
                        }
                    }
                    else
                    {
                        exp.Add(0);
                        if (parts[0].Contains("/"))
                        {
                            int n, d;
                            string[] fraction = parts[0].Split('/');
                            int.TryParse(fraction[0], out n);
                            int.TryParse(fraction[1], out d);
                            coef.Add(new Fraction(n, d));
                        }
                        else
                        {
                            int n;
                            int.TryParse(parts[0], out n);
                            coef.Add(n);
                        }
                    }
                }
            }
            Polynom P = new Polynom(coef, exp).Simplify();

            return P;
        }

    }
}
