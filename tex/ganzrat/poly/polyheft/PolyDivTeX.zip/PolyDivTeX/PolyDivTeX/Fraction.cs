﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PolyDivTeX
{
    class Fraction
    {
        int num = 0; // numerator // Zähler
        int den = 1; // denominator // Nenner

        public Fraction(int n=0, int d=1)
        {
            num = n; den = d != 0 ? d : 1;
            ReduceL();
        }
        public int Numerator // Zähler
        {
            get { return num;  }
            set { num = value; }
        }
        public int Denominator // Nenner
        {
            get { return den; }
            set { den = value != 0 ? value : 1; }
        }

        public static Fraction operator+(Fraction A, Fraction B)
        {
            if (A.Numerator == 0)
                return B;
            if (B.Numerator == 0)
                return A;

            Fraction C = new Fraction(A.Numerator*B.Denominator + B.Numerator*A.Denominator, A.Denominator*B.Denominator);

            return C;
        }
        public static Fraction operator -(Fraction A, Fraction B)
        {
            if (A.Numerator == 0)
                return -1 * B;
            if (B.Numerator == 0)
                return A;

            Fraction C = new Fraction(A.Numerator * B.Denominator - B.Numerator * A.Denominator, A.Denominator * B.Denominator);

            return C;
        }
        public static Fraction operator*(Fraction A, Fraction B)
        {
            Fraction C = new Fraction(A.Numerator * B.Numerator, A.Denominator * B.Denominator);
            C.ReduceL();

            return C;
        }
        public static Fraction operator /(Fraction A, Fraction B)
        {
            return A*B.Inverse();
        }

        public static implicit operator Fraction(int i)
        {
            return new Fraction(i);
        }

        public Fraction Inverse() // Multiplicative Inverse // Reziproke/Kehrwert 
        {
            return new Fraction(this.Denominator, this.Numerator);
        }

        void ReduceH(Fraction a) // reduce to higher terms // erweitern
        {
            int h = GetFactor(Denominator, LCM(this.Denominator, a.Denominator));
            Numerator *= h;
            Denominator *= h;
        }

        void ReduceL() // Reduce to lower terms // kürzen
        {
            int h = GCD(Numerator, Denominator);
            Numerator /= h;
            Denominator /= h;

            if (Denominator < 0)
            {
                Numerator *= -1;
                Denominator *= -1;
            }

        }
        public static int GCD(int a, int b) // Greatest Common Divisor // größter gemeinsamer Teiler // code by de.wikipedia.org
        {
            int h;
            if (a == 0) return Math.Abs(b);
            if (b == 0) return Math.Abs(a);
            do
            {
                h = a % b;
                a = b;
                b = h;
            } while (b != 0);
            return Math.Abs(a);
        }
        public static int LCM(int a, int b) // Least Common Multiple // kleinstes gemeinsames Vielfaches
        {
            a = Math.Abs(a);
            b = Math.Abs(b);

            if (a == 0) return 1;
            if (b == 0) return 1;

            return PrimeFactorization.LCM(a, b);
        }
        
        int GetFactor(int a, int b) // a * x = b // Get factor for reducing // Faktor für Erweiterung erhalten
        {
            return b / a;
        }
        public override string ToString()
        {
            return Denominator == 1 ? Numerator.ToString() : Numerator.ToString() + "/" + Denominator.ToString();
        }
        public string ToTexString(bool sign = true)
        {
            return Denominator == 1 ? (sign ? Numerator.ToString() : Math.Abs(Numerator).ToString()) : (sign? (Numerator < 0 ? "-" : ""): "") + "\\tfrac{" + Math.Abs(Numerator).ToString() + "}{" + Denominator.ToString() + "}";
        }
        public bool IsOne()
        {
            return Math.Abs(Numerator) == 1 && Denominator == 1;
        }
        public bool Sign()
        {
            return Numerator >= 0; // true = + // false = -
        }
    }
}
