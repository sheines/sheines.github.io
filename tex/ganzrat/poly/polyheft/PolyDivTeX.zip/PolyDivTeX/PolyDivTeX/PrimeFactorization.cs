﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PolyDivTeX
{
    class PrimeFactorization
    {
        public PrimeFactorization(int value) 
        {
            Value = value < 0 ? -value : value;
            Primes = new List<int>();
            Exponents = new List<int>();
            GetFactorization();
        }
        void GetFactorization() // Calculate Prime Factorization // Primfaktorzerlegung berechnen
        {
            if (Value == 1)
            {
                Primes.Add(1);
                Exponents.Add(1);
                return;
            }

            int v = Value;
            int index;
            while (v>1)
            {
                for (int i = 2; i<=v; ++i)
                {
                    if (v % i == 0)
                    {
                        if (Primes.Contains(i))
                        {
                            index = Primes.IndexOf(i);
                            Exponents[index] += 1;
                        }
                        else
                        {
                            Primes.Add(i);
                            Exponents.Add(1);
                        }
                        v /= i;
                        break;
                    }
                }
            }
        }
        public override string ToString()
        {
            string str = Value.ToString() + " = ";

            for (int i = 0; i < Primes.Count; ++i)
                str += (i > 0 ? " * " : "") + Primes[i].ToString() + "^" + Exponents[i].ToString();

            return str;
        }

        public static int LCM (PrimeFactorization A, PrimeFactorization B) // Least common Multiple // Kleinstes gemeinsames Vielfaches
        {
            int max = A.Primes.Max() > B.Primes.Max() ? A.Primes.Max() : B.Primes.Max();
            int expA, expB;

            PrimeFactorization C = new PrimeFactorization(1);

            for (int i = 2; i<=max; ++i)
            {
                if (A.Primes.Contains(i) || B.Primes.Contains(i))
                {
                    C.Primes.Add(i);
                    if (A.Primes.Contains(i))
                    {
                        expA = A.Primes.IndexOf(i);
                        expA = A.Exponents[expA];
                    }
                    else
                        expA = 0;
                    if (B.Primes.Contains(i))
                    {
                        expB = B.Primes.IndexOf(i);
                        expB = B.Exponents[expA];
                    }
                    else
                        expB = 0;


                    C.Exponents.Add(expA > expB ? expA : expB);
                }
            }

            max = 1;
            for (int i = 0; i < C.Primes.Count; ++i)
                max *= GetPower(C.Primes[i], C.Exponents[i]);

            return max;
        }
        static int GetPower(int a, int b) // a ^ b, b >= 0
        {
            if (b == 0)
                return 1;

            int c = a;
            for (int i = 1; i < b; ++i)
                c *= a;
            return c;
        }

        public static implicit operator PrimeFactorization(int i)
        {
            return new PrimeFactorization(i);
        }

        public int Value { get; private set; } = 1;
        public List<int> Exponents { get; private set; } = new List<int>();
        public List<int> Primes { get; private set; } = new List<int>();

        

    }
}
