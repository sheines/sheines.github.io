﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace PolyDivTeX
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer stringObserver;
        public MainWindow()
        {
            InitializeComponent();

            StringSave.Clear();

            stringObserver = new DispatcherTimer();
            stringObserver.Tick += new EventHandler(stringObserver_Tick);
            stringObserver.Interval = new TimeSpan(0, 0, 1);
            stringObserver.Start();

        }

        private void TestButton_Click(object sender, RoutedEventArgs e)
        {
            Polynom P = Polynom.GetPolynom(tbPoly1.Text);
            Polynom Q = Polynom.GetPolynom(tbPoly2.Text);

            Fraction a = new Fraction(-4, 3);
            Fraction b = new Fraction(1,2);

            Fraction c = new Fraction();


            c = a + b;

            MessageBox.Show((a+b).ToString());





            //Polynom R = P + Q;

            //MessageBox.Show(P.ToString() + "\n" + Q.ToString() + "\n" + R.ToString());




        }
    }
}
