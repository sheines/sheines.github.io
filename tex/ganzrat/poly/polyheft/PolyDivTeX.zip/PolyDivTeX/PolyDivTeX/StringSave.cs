﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PolyDivTeX
{
    static class StringSave
    {
        static public string Text
        {
            get; set;
        }
        static public void Add(string s)
        {
            Text += s;
        }
        static public void AddLine(string s)
        {
            Text +="\n" + s;
        }
        static public void Clear()
        {
            Text = "";
        }
    }
}
