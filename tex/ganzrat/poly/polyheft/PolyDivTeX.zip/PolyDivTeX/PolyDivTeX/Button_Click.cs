﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace PolyDivTeX
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Polynom P1 = Polynom.GetPolynom(tbPoly1.Text);
            Polynom P2 = Polynom.GetPolynom(tbPoly2.Text);

            Polynom P3 = new Polynom();

            StringSave.Clear();
            StringSave.Add("\\arraycolsep=1.4pt\n");
            StringSave.Add("\\begin{array}[t]{*{25}{r}}\n");

            if (cbTeX.IsChecked == true)
                Polynom.TeX = true;

            if (rbAddition.IsChecked == true)
                P3 = P1 + P2;
            else if (rbSubtraction.IsChecked == true)
                P3 = P1 - P2;
            else if (rbMultiplication.IsChecked == true)
                P3 = P1 * P2;
            else
                P3 = P1 / P2;

            tbPoly3.Text = P3.ToString();


            StringSave.Add("\n\\end{array}");

        }


    }
}
